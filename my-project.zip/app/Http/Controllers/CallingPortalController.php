<?php
// app/Http/Controllers/CallingPortalController.php

namespace App\Http\Controllers;

use App\Models\Lead;
use Illuminate\Http\Request;

class CallingPortalController extends Controller
{
    public function index()
    {
        $leads = Lead::where('status', 'new')->get(); // Example: fetching new leads for calling
        return view('calling-portal', compact('leads'));
    }

    public function updateLeadStatus($id, Request $request)
    {
        $lead = Lead::find($id);
        $lead->status = $request->status;
        $lead->save();

        return redirect()->back()->with('success', 'Lead status updated successfully.');
    }
}
