<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Lead;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $totalUsers = User::count();
        $activeUsers = User::where('status', 'active')->count();
        $newLeads = Lead::where('status', 'new')->count();
        $monthlyRevenue = Lead::sum('revenue');

        // Fetch data for the chart
        $userCounts = User::selectRaw('COUNT(*) as count, MONTH(created_at) as month')
            ->groupBy('month')
            ->orderBy('month')
            ->pluck('count', 'month')
            ->toArray();

        $revenueData = Lead::selectRaw('SUM(revenue) as total, MONTH(created_at) as month')
            ->groupBy('month')
            ->orderBy('month')
            ->pluck('total', 'month')
            ->toArray();

        // Ensure data arrays have 12 months
        $userCounts = $this->fillMissingMonths($userCounts);
        $revenueData = $this->fillMissingMonths($revenueData);

        return view('dashboard', compact('totalUsers', 'activeUsers', 'newLeads', 'monthlyRevenue', 'userCounts', 'revenueData'));
    }

    private function fillMissingMonths($data)
    {
        $filledData = array_fill(1, 12, 0);
        foreach ($data as $month => $value) {
            $filledData[$month] = $value;
        }
        return array_values($filledData);
    }
}