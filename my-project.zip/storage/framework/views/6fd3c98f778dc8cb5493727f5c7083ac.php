

<?php $__env->startSection('content'); ?>
<div class="p-8">
    <!-- Page Heading -->
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-3xl font-semibold text-gray-700">Calling Portal</h1>
        <button class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600">
            Retry All
        </button>
    </div>

    <!-- Search and Filters -->
    <div class="mb-4 flex justify-between items-center">
        <!-- Search Bar -->
        <input 
            type="text" 
            placeholder="Search by phone number..." 
            class="border border-gray-300 p-2 rounded-lg w-1/2 focus:outline-none focus:ring-2 focus:ring-green-500"
        />

        <!-- Status Filter Dropdown -->
        <div class="relative">
            <select class="border border-gray-300 p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <option value="">All Statuses</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
            </select>
        </div>
    </div>

    <!-- Call List Table -->
    <div class="bg-white shadow-lg rounded-lg overflow-hidden">
        <table class="min-w-full leading-normal">
            <thead>
                <tr>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Phone Number</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Date</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Status</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Example Row 1 -->
                <tr>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">9801821680</p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">26-Aug-2024</p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <span class="relative inline-block px-3 py-1 font-semibold text-green-900 leading-tight">
                            <span class="absolute inset-0 bg-green-200 opacity-50 rounded-full"></span>
                            <span class="relative">Completed</span>
                        </span>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <button class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">View</button>
                    </td>
                </tr>

                <!-- Example Row 2 -->
                <tr>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">9876543210</p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">26-Aug-2024</p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <span class="relative inline-block px-3 py-1 font-semibold text-red-900 leading-tight">
                            <span class="absolute inset-0 bg-red-200 opacity-50 rounded-full"></span>
                            <span class="relative">Failed</span>
                        </span>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <button class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600">Retry</button>
                    </td>
                </tr>

                <!-- Example Row 3 -->
                <tr>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">9123456780</p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">25-Aug-2024</p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <span class="relative inline-block px-3 py-1 font-semibold text-yellow-900 leading-tight">
                            <span class="absolute inset-0 bg-yellow-200 opacity-50 rounded-full"></span>
                            <span class="relative">Pending</span>
                        </span>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <button class="bg-yellow-500 text-white px-4 py-2 rounded-md hover:bg-yellow-600">Complete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Pagination (if necessary) -->
    <div class="flex justify-between mt-4">
        <p class="text-sm text-gray-600">Showing 1 to 10 of 50 entries</p>
        <div class="inline-flex">
            <button class="bg-gray-200 text-gray-700 px-3 py-2 rounded-l hover:bg-gray-300">Prev</button>
            <button class="bg-gray-200 text-gray-700 px-3 py-2 rounded-r hover:bg-gray-300">Next</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel-excel\my-project\resources\views/calling-portal.blade.php ENDPATH**/ ?>