


<?php $__env->startSection('content'); ?>
<div class="p-8">

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-3xl font-semibold text-gray-700">Leads</h1>
        <div>
        <a href="<?php echo e(route('leads.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
            Add New Lead
        </a>
        <a href="<?php echo e(route('leads.upload')); ?>" class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 ml-2">
            Upload Leads
        </a>
        </div>
    </div>

    <!-- Search and Filters -->
    <form method="GET" action="<?php echo e(route('leads')); ?>" class="mb-4 flex flex-col lg:flex-row lg:justify-between lg:items-center">
        <!-- Search Bar -->
        <input 
            type="text" 
            name="search"
            placeholder="Search by name, number, or occupation..." 
            class="border border-gray-300 p-2 rounded-lg w-full lg:w-1/2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            value="<?php echo e(request('search')); ?>"
        />

        <!-- Filters -->
        <div class="flex flex-col lg:flex-row mt-4 lg:mt-0 space-y-2 lg:space-y-0 lg:space-x-4">
            <div class="relative">
                <select name="occupation" class="border border-gray-300 p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">All Occupations</option>
                    <option value="student" <?php echo e(request('occupation') == 'student' ? 'selected' : ''); ?>>Student</option>
                    <option value="professional" <?php echo e(request('occupation') == 'professional' ? 'selected' : ''); ?>>Professional</option>
                    <option value="entrepreneur" <?php echo e(request('occupation') == 'entrepreneur' ? 'selected' : ''); ?>>Entrepreneur</option>
                </select>
            </div>
            <div class="relative">
                <select name="status" class="border border-gray-300 p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">All Statuses</option>
                    <option value="new" <?php echo e(request('status') == 'new' ? 'selected' : ''); ?>>New</option>
                    <option value="contacted" <?php echo e(request('status') == 'contacted' ? 'selected' : ''); ?>>Contacted</option>
                    <option value="converted" <?php echo e(request('status') == 'converted' ? 'selected' : ''); ?>>Converted</option>
                    <option value="lost" <?php echo e(request('status') == 'lost' ? 'selected' : ''); ?>>Lost</option>
                </select>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Filter</button>
        </div>
    </form>

    <!-- Leads Table -->
    <div class="bg-white shadow-lg rounded-lg overflow-hidden">
        <table class="min-w-full leading-normal">
            <thead>
                <tr>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Date</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Name</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Number</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Occupation</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Status</th>
                    <th class="px-5 py-3 bg-gray-50 text-gray-800 text-left text-sm uppercase font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($lead->created_at->format('d-M-Y')); ?></p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($lead->name); ?></p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($lead->phone); ?></p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($lead->occupation); ?></p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <span class="relative inline-block px-3 py-1 font-semibold text-<?php echo e($lead->status_color); ?>-900 leading-tight">
                            <span class="absolute inset-0 <?php echo e($lead->status_background_color); ?> opacity-50 rounded-full"></span>
                            <span class="relative"><?php echo e(ucfirst($lead->status)); ?></span>
                        </span>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <a href="<?php echo e(route('leads.show', $lead)); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">View</a>
                        <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="bg-yellow-500 text-white px-4 py-2 rounded-md hover:bg-yellow-600 ml-2">Edit</a>
                        <form action="<?php echo e(route('leads.destroy', $lead)); ?>" method="POST" class="inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 ml-2">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="flex justify-between mt-4">
        <p class="text-sm text-gray-600">Showing <?php echo e($leads->firstItem()); ?> to <?php echo e($leads->lastItem()); ?> of <?php echo e($leads->total()); ?> entries</p>
        <div class="inline-flex">
            <?php echo e($leads->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel-excel\my-project\resources\views/leads.blade.php ENDPATH**/ ?>