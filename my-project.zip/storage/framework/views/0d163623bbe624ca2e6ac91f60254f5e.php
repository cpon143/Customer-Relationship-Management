<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Consultancy Dashboard</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex flex-col">

        <!-- Display Error Message -->
        <!-- <?php if(session('error')): ?>
            <div class="bg-red-500 text-white p-4 rounded mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?> -->

        <!-- Navbar -->
        <nav class="bg-green-600 p-4 text-white shadow-lg">
            <div class="container mx-auto flex justify-between items-center">
                <div class="text-xl font-bold">
                    Student’s Choice Consultancy
                </div>
                <div class="flex space-x-4">
                    <a href="<?php echo e(url('/')); ?>" class="<?php echo e(Route::currentRouteName() == 'dashboard' ? 'text-yellow-400' : 'hover:text-yellow-400'); ?>">Dashboard</a>
                    <a href="<?php echo e(route('calling-portal')); ?>" class="<?php echo e(Route::currentRouteName() == 'calling-portal' ? 'text-yellow-400' : 'hover:text-yellow-400'); ?>">Calling Portal</a>
                    <a href="<?php echo e(route('report')); ?>" class="<?php echo e(Route::currentRouteName() == 'report' ? 'text-yellow-400' : 'hover:text-yellow-400'); ?>">Report</a>
                    <a href="<?php echo e(route('settings')); ?>" class="<?php echo e(Route::currentRouteName() == 'settings' ? 'text-yellow-400' : 'hover:text-yellow-400'); ?>">Settings</a>
                    <a href="<?php echo e(route('leads')); ?>" class="<?php echo e(Route::currentRouteName() == 'leads' ? 'text-yellow-400' : 'hover:text-yellow-400'); ?>">Leads</a>
                    <a href="<?php echo e(route('admins')); ?>" class="<?php echo e(Route::currentRouteName() == 'admins' ? 'text-yellow-400' : 'hover:text-yellow-400'); ?>">Admin</a>
                    
                    <!-- Login/Logout Button -->
                    <!-- <?php if(Auth::check()): ?>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="text-white hover:text-yellow-400">Logout</button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-white hover:text-yellow-400">Login</a>
                    <?php endif; ?> -->

                    <?php if(Auth::guard('admin')->check() || Auth::guard('advisor')->check()): ?>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="text-white hover:text-yellow-400">Logout</button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-white hover:text-yellow-400">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>

        <!-- Sidebar and Main Content -->
        <div class="flex flex-1">
            <!-- Sidebar -->
            <aside class="w-64 bg-white shadow-md">
                <div class="p-6 text-center font-bold text-xl text-green-600">
                    Student’s Choice Consultancy
                </div>
                <nav class="mt-10">
                    <a href="<?php echo e(url('/')); ?>" class="block py-2.5 px-4 <?php echo e(Route::currentRouteName() == 'dashboard' ? 'bg-green-200 text-green-700' : 'text-gray-700 hover:bg-green-200 hover:text-green-700'); ?>">
                        Dashboard
                    </a>
                    <a href="<?php echo e(route('calling-portal')); ?>" class="block py-2.5 px-4 <?php echo e(Route::currentRouteName() == 'calling-portal' ? 'bg-green-200 text-green-700' : 'text-gray-700 hover:bg-green-200 hover:text-green-700'); ?>">
                        Calling Portal
                    </a>
                    <a href="<?php echo e(route('report')); ?>" class="block py-2.5 px-4 <?php echo e(Route::currentRouteName() == 'report' ? 'bg-green-200 text-green-700' : 'text-gray-700 hover:bg-green-200 hover:text-green-700'); ?>">
                        Report
                    </a>
                    <a href="<?php echo e(route('settings')); ?>" class="block py-2.5 px-4 <?php echo e(Route::currentRouteName() == 'settings' ? 'bg-green-200 text-green-700' : 'text-gray-700 hover:bg-green-200 hover:text-green-700'); ?>">
                        Settings
                    </a>
                    <a href="<?php echo e(route('leads')); ?>" class="block py-2.5 px-4 <?php echo e(Route::currentRouteName() == 'leads' ? 'bg-green-200 text-green-700' : 'text-gray-700 hover:bg-green-200 hover:text-green-700'); ?>">
                        Leads
                    </a>
                    <a href="<?php echo e(route('admins')); ?>" class="block py-2.5 px-4 <?php echo e(Route::currentRouteName() == 'admins' ? 'bg-green-200 text-green-700' : 'text-gray-700 hover:bg-green-200 hover:text-green-700'); ?>">
                        Admin
                    </a>
                </nav>
            </aside>

            <!-- Main Content -->
            <main class="flex-1 p-6 bg-gray-50">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH F:\laravel-excel\my-project\resources\views/layouts/app.blade.php ENDPATH**/ ?>